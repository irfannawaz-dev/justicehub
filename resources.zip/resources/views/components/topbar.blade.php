@php
    $pageTitles = [
        'dashboard'                  => 'Strategic Overview',
        'dashboard.litigation-adr'   => 'Litigation & ADR Dashboard',
        'dashboard.lcd'              => 'LCD Dashboard',
        'cases.index'                => 'Case Management',
        'cases.show'                 => 'Case File',
        'intake.create'              => 'Client Intake & Registration',
        'services.adr'               => 'ADR Scorecard',
        'services.adr-calendar'      => 'ADR Calendar',
        'services.litigation'        => 'Litigation Scorecard',
        'services.litigation-calendar'=> 'Litigation Calendar',
        'referrals.index'            => 'Referrals & Linkages',
        'outreach.index'             => 'Outreach & Legal Literacy',
        'complaints.index'           => 'Complaints Register',
        'indicators.index'           => 'Results Framework & Indicators',
        'evidence.index'             => 'Evidence Register',
        'feedback.index'             => 'Client Feedback',
        'staff.index'                => 'Staff & Training Register',
        'learning.index'             => 'Learning, Evidence & VfM',
        'impact.index'               => 'Impact Reports',
        'settings.index'             => 'Settings & Preferences',
    ];
    $currentRoute = Route::currentRouteName() ?? '';
    $pageTitle    = $pageTitles[$currentRoute] ?? 'Justice Hub';
    $isDark       = session('theme', 'light') === 'dark';
@endphp

<header style="background: var(--paper); border-bottom: 1px solid var(--rule); padding: 0 28px; height: 56px; display: flex; align-items: center; gap: 18px; flex-shrink: 0;">

    {{-- Breadcrumb / Page title --}}
    <div style="flex: 1; min-width: 0;">
        <div style="display: flex; align-items: center; gap: 8px;">
            <div class="label-cap" style="font-size: 9px; white-space: nowrap;">Justice Hub</div>
            <x-lucide-chevron-right style="width: 10px; height: 10px; color: var(--ink-4);" />
            <div style="font-size: 14px; font-weight: 500; color: var(--ink); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                {{ $pageTitle }}
            </div>
        </div>
    </div>

    {{-- Global search --}}
    <div data-jh-search style="position: relative; width: 280px;">
        <div style="position: relative;">
            <x-lucide-search style="width: 14px; height: 14px; position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--ink-4);" />
            <input
                id="jh-search-input"
                type="text"
                placeholder="Search cases… ⌘K"
                class="inp"
                style="padding-left: 34px; padding-right: 12px; font-size: 13px; height: 36px;"
                autocomplete="off"
            >
        </div>

        {{-- Search results dropdown --}}
        <div
            id="jh-search-dropdown"
            style="display: none; position: absolute; top: 100%; left: 0; right: 0; z-index: 100; background: var(--paper); border: 1px solid var(--rule); box-shadow: var(--shadow-card); max-height: 320px; overflow-y: auto; margin-top: 4px;"
        >
            <div id="jh-search-results"></div>
        </div>
    </div>

    {{-- Theme toggle --}}
    @php $themeUrl = route('settings.theme'); $csrf = csrf_token(); @endphp
    <button
        onclick="jhSetTheme(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark', '{{ $csrf }}', '{{ $themeUrl }}')"
        style="background: none; border: 1px solid var(--rule); padding: 7px 9px; cursor: pointer; color: var(--ink-2); display: flex; align-items: center;"
        title="Toggle theme"
    >
        <span id="jh-icon-sun"  style="{{ $isDark ? 'display:none' : '' }}">
            <x-lucide-sun style="width: 15px; height: 15px;" />
        </span>
        <span id="jh-icon-moon" style="{{ $isDark ? '' : 'display:none' }}">
            <x-lucide-moon style="width: 15px; height: 15px;" />
        </span>
    </button>

    {{-- Notification bell --}}
    <button style="background: none; border: none; cursor: pointer; color: var(--ink-3); position: relative; padding: 4px;">
        <x-lucide-bell style="width: 17px; height: 17px;" />
    </button>

    {{-- User dropdown (Bootstrap) --}}
    <div class="dropdown" style="position: relative;">
        <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"
            style="background: none; border: none; cursor: pointer; display: flex; align-items: center; gap: 6px; padding: 4px;">
            <div style="width: 28px; height: 28px; background: var(--forest); color: var(--cream); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 500;">
                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
            </div>
            <x-lucide-chevron-down style="width: 11px; height: 11px; color: var(--ink-4);" />
        </button>

        <ul class="dropdown-menu dropdown-menu-end" style="min-width: 180px; padding: 0; border: 1px solid var(--rule); border-radius: 4px; background: var(--paper); box-shadow: 0 6px 20px rgba(0,0,0,.12); margin-top: 8px;">
            <li style="padding: 12px 16px; border-bottom: 1px solid var(--rule-2);">
                <div style="font-size: 13px; font-weight: 500; color: var(--ink);">{{ auth()->user()->name }}</div>
                <div style="font-size: 11px; color: var(--ink-3); margin-top: 2px;">{{ auth()->user()->role->label() }}</div>
            </li>
            <li>
                <a href="{{ route('profile.edit') }}" class="dropdown-item tr-hover"
                   style="display: block; padding: 10px 16px; font-size: 13px; color: var(--ink-2); text-decoration: none; background: transparent;">
                    My Profile
                </a>
            </li>
            @if(auth()->user()->can('settings.view'))
            <li>
                <a href="{{ route('settings.index') }}" class="dropdown-item tr-hover"
                   style="display: block; padding: 10px 16px; font-size: 13px; color: var(--ink-2); text-decoration: none; background: transparent;">
                    Settings
                </a>
            </li>
            @endif
            <li>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="dropdown-item tr-hover"
                        style="width: 100%; padding: 10px 16px; font-size: 13px; color: var(--burgundy); text-align: left; border: none; background: none; cursor: pointer; font-family: inherit;">
                        Sign Out
                    </button>
                </form>
            </li>
        </ul>
    </div>
</header>

{{-- Remove Bootstrap's auto-caret on the user dropdown toggle --}}
<style>
    header .dropdown-toggle::after { display: none !important; }
    header .dropdown-item:hover, header .dropdown-item:focus { background: var(--parchment-2) !important; color: var(--ink) !important; }
</style>
